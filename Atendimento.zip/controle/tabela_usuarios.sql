
CREATE TABLE `usuarios` (
  `id` bigint(3) NOT NULL auto_increment,
  `username` varchar(20) default NULL,
  `senha` varchar(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;
