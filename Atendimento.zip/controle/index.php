<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Controle de Atendimentos</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
.style3 {font-size: 12px; font-weight: bold; color: #0099FF; }
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4" link="#663300" vlink="#663300" alink="#663300">
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="1%" border="0" align="center" cellspacing="1">
  <tr> 
    <td colspan="5"><p align="center">&nbsp;</p></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="3"><p align="center"><img src="imagens/new_logo.jpg" width="276" height="65" /></p>
      </td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
    <td colspan="3"><p align="center">&nbsp;</p>
      </td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td colspan="5"><div align="center"> 
        <p><font color="#663300" size="+1" face="Arial, Helvetica, sans-serif"><strong>Clique 
          na &aacute;rea que deseja entrar<br />
          </strong></font></p>
      </div></td>
  </tr>
  <tr> 
    <td width="1%">&nbsp;</td>
    <td width="47%"><div align="center"><a href="admincontrole/index.php"><img src="imagens/adm.gif" width="150" height="143" border="0" /></a></div></td>
    <td width="2%">&nbsp;</td>
    <td width="50%"><div align="center"><a href="suportecontrole/index.php"><img src="imagens/suporte.gif" width="150" height="112" border="0" /></a></div></td>
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><font size="1">&nbsp;</font></td>
    <td><div align="center"><font color="#663300" size="1"><strong><font face="Verdana, Arial, Helvetica, sans-serif"><a href="admincontrole/index.php">Administrativo</a></font></strong></font></div></td>
    <td><font color="#663300" size="1">&nbsp;</font></td>
    <td><div align="center"><font color="#663300" size="1"><strong><font face="Verdana, Arial, Helvetica, sans-serif"><a href="suportecontrole/index.php"> 
        Suporte - Atendimento</a></font></strong></font></div></td>
    <td><font size="1">&nbsp;</font></td>
  </tr>
</table>
<p>&nbsp;</p>
</html>