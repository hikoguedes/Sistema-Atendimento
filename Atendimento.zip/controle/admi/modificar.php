<?php
include "status.php";
?>
<?php
include "connect.php";
?>
<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>MODIFICAR</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
.style3 {font-size: 12px; font-weight: bold; color: #000066; }
.style8 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
	letter-spacing: 0.2em;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4">
  <?php


if (getenv("REQUEST_METHOD") == "POST") {
   $id = $_POST['id'];
  {
$query = "SELECT COUNT(*) FROM registros WHERE estado = 'finalizado' AND  tecnico = '$login_usuario' ORDER BY data_status DESC";
$query = mysql_query($query,$conexao);
$query = mysql_fetch_array($query);
$total = $query[0];
       }
}
      
?>

<?php

$begin = $_GET['begin'];
if (!$begin) { $begin = 0; }


$conexao = mysql_connect("localhost","root","1qaz2wsx");
mysql_select_db("suporte",$conexao);


//$query = "SELECT COUNT(*) FROM registros WHERE estado = 'finalizado' AND  tecnico = '$login_usuario' ORDER BY data_status DESC";
//$query = mysql_query($query,$conexao);
//$query = mysql_fetch_array($query);
//$total = $query[0];

?>
<tr>
<td height="490">&nbsp;
      <span class="bodyText">

      </span>
    <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
      <tr> 
        <td height="46" class="pageName"><div align="center"> 
            <p>Modificar Chamado</p>
          </div></td>
      </tr>
      <tr> 
        <td height="19" class="bodyText"><p align="center" class="style1">Altere 
            os itens desejados e clique no botao &quot;MODIFICAR&quot;</p></td>
      </tr>
    </table>
      <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr>
          <td height="20" class="bodyText">&nbsp;
          <div align="center"></div></td>
        </tr>
      </table>
	
    <p align="center" class="pageName">
    <?php

$query = "SELECT DISTINCT * FROM registros WHERE estado = 'finalizado' AND  id = '$id' ORDER BY data_status DESC";
$query = mysql_query($query,$conexao);


while ($linha = mysql_fetch_array($query)) {

   $var = $linha['data_aber'];
   $var = explode(" ",$var);
   $dia = $var[0];
   $hora = $var[1];
   $dia = explode("-",$dia);
   $data = "$dia[2]/$dia[1]/$dia[0] �s $hora";
   $zar = $linha['data_status'];
   $zar = explode(" ",$zar);
   $dia2 = $zar[0];
   $hora2 = $zar[1];
   $dia2 = explode("-",$dia2);
   $data2 = "$dia2[2]/$dia2[1]/$dia2[0] �s $hora2";   
   $yar = $linha['data_fim'];
   $yar = explode(" ",$yar);
   $dia3 = $yar[0];
   $hora3 = $yar[1];
   $dia3 = explode("-",$dia3);
   $data3= "$dia3[2]/$dia3[1]/$dia3[0] �s $hora3";  
   ?></p>
    <form name="form1" id="form1" method="post" action="update_modificar.php">
      <table width="675" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr> 
          <td class="subHeader" id="monthformat">Setor</td>
          <td width="175" class="style8" id="monthformat"><span class="style8"> 
            <input name="setor" type="text" id="setor" value="<?php echo $linha['setor']; ?>" size="50"/>
            </span></td>
          <td width="49" class="style8" id="monthformat"><font color="#993300">Ramal</font></td>
          <td width="144" class="style8" id="monthformat"><span class="style8"> 
            <input type="text" name="ramal" id="ramal" value="<?php echo $linha['ramal']; ?>"/>
            </span></td>
          <td width="37" class="style8" id="monthformat"><font color="#993300">ID</font></td>
          <td width="68" class="style8" id="monthformat"><?php echo $linha['id']; ?><span class="style8">
            <input name="id" type="hidden" id="id" value="<?php echo $linha['id']; ?>" size="50"/>
            </span></td>
        </tr>
        <tr> 
          <td width="178" class="subHeader" id="monthformat">Andar</td>
          <td colspan="5" class="style8" id="monthformat"> <span class="style8"> 
            <input name="andar" type="text" id="andar" value="<?php echo $linha['andar']; ?>" size="50"/>
            </span> <div align="left" class="subHeader"> 
              <div align="right"></div>
            </div>
            <div align="right"></div></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Contato</td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8"> 
            <input name="contato" type="text" id="contato" value="<?php echo $linha['contato']; ?>" size="50"/>
            </span></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Equipamento</td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8"> 
            <input name="equip" type="text" id="equip" value="<?php echo $linha['equip']; ?>" size="50"/>
            </span></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">T&eacute;cnico</td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8"> 
            <input name="tecnico" type="text" id="tecnico" value="<?php echo $linha['tecnico']; ?>" size="50"/>
            </span></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Status</td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8"> 
            <input name="estado" type="text" id="estado" value="<?php echo $linha['estado']; ?>" size="50"/>
            </span></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Problema Reportado</td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8"> 
            <textarea name="prob_rep" id="prob_rep" cols="70"><?php echo $linha['prob_rep']; ?></textarea>
            </span></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Problema Encontrado 
          </td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8">
            <textarea name="prob_enc" id="prob_enc" cols="70"><?php echo $linha['prob_enc']; ?></textarea>
            </span></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat"><p>Solu&ccedil;&atilde;o 
            </p></td>
          <td colspan="5" class="style8" id="monthformat"><span class="style8">
            <textarea name="solucao" id="solucao" cols="70"><?php echo $linha['solucao']; ?></textarea>
            </span></td>
        </tr>
        <tr align="right"> 
          <td colspan="6" valign="top" class="subHeader" id="monthformat"></td>
        </tr>
        <tr valign="bottom"> 
          <td height="27" colspan="6" align="right" class="subHeader" id="monthformat"> 
            <div align="center">
              <input type="submit" name="Submit" value="Modificar" />
            </div></td>
        </tr>
      </table>
    </form>
    <p>&nbsp;</p>
    <p>&nbsp;    </p>
    <p>&nbsp;</p>
    <p>
      <?php
	  }
	  ?>
    </p>

    </div></html>