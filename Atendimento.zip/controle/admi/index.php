<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Controle de Atendimentos - Suporte T�cnico</title>
</head>

<frameset rows="150,*" frameborder="NO" border="0" framespacing="0">
  <frame src="top.php" name="topFrame" scrolling="NO" noresize title="topFrame" >
  <frame src="logar.php" name="main" title="main">
</frameset>
<noframes><body>
</body></noframes>
</html>
