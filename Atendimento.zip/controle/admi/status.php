<?php echo "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?".">"; ?>
<?php
session_start();
if (isset($_SESSION["login_usuario"]) AND isset($_SESSION["senha_usuario"])) {
    $login_usuario = $_SESSION["login_usuario"];
    $senha_usuario = $_SESSION["senha_usuario"];
}else{
header("Location: logar.php");
exit();/*caso nao tinha session.. quer dizer.. ele nao logou*/
} /*aqui primeiro ele checa para ver se exite essas Sessoes, e depois ele coloca o valor das sessoes nessas variaveis... para fazermos os testes!*/

if(!(empty($login_usuario) OR empty($senha_usuario)))
{
//acessa ao banco de dados
$cn = mysql_connect("localhost", "root", "1qaz2wsx");
mysql_select_db("suporte");
$resultado = mysql_query("select * from adm where username = '$login_usuario'");
if (mysql_num_rows($resultado) == 1)/*caso exista esse login.. vamos testar a senha entao*/
{
   if ($senha_usuario != mysql_result($resultado, 0, "senha"))
   {
       unset ($_SESSION["nome_usuario"]);/*apaga a session que existia mas era errada..*/
       unset ($_SESSION["sehna_usuario"]);
       header("Location: logar.php");
       exit();
   } 
}else {
       unset ($_SESSION["nome_usuario"]);
       unset ($_SESSION["sehna_usuario"]);
       header("Location: logar.php");
       exit();
}

}else{
header("Location: logar.php");
exit();/*caso das sessions estarem vazias*/
}
mysql_close($cn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4" link="#666666" vlink="#666666" alink="#666666">
<tr>
    
  <td height="490"> <div align="right"></div>
    <table width="116" border="0" align="left" cellpadding="2" cellspacing="0" bordercolor="#993300">
      <tr> 
        <td width="79" height="20" class="bodyText"> 
          <div align="center"><?php echo "$login_usuario"; ?></div></td>
        <td width="29" class="bodyText">
<div align="center">
            <p><a href="logout.php"><font color="#666666">logout</font></a></p>
          </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
<?php
include "cfonte.php";
?>
</html>
