<?php
include "valida_session.php";
?>

<?php

$conexao = mysql_connect("localhost","","");
mysql_select_db("suporte",$conexao);

?>