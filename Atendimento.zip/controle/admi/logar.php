<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Calendar</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4">
<form method="post" action="login.php">



 <tr>
    <td height="490"><p>&nbsp;
    &nbsp;<br />
    </p>
      <p>&nbsp;</p>
      <p>&nbsp;</p>
      <table width="232" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr> 
          <td height="46" colspan="4" class="pageName"><div align="center"> 
              <p><img src="imagens/cadeado.gif" width="24" height="24" /></p>
              <p>Identifique-se</p>
            </div></td>
        </tr>
        <tr> 
          <td height="54" colspan="4" class="bodyText"> 
            <p align="center" class="style1"><span class="style1">Entre 
              aqui com o seu Login e Senha para acessar o sistema.</span></p>
            </td>
        </tr>
        <tr> 
          <td width="76" class="subHeader" id="monthformat">Login</td>
          <td width="180" colspan="3" class="subHeader" id="monthformat"><input name="login" type="text" id="login" size="30" /></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Senha</td>
          <td colspan="3" class="subHeader" id="monthformat"><input name="senha" type="password" id="senha" value="" size="30" /></td>
        </tr>
        <tr> 
          <td colspan="4" valign="top" class="subHeader" id="monthformat">&nbsp;</td>
        </tr>
      </table>
    <table width="226" border="0" align="center" cellspacing="2">
      <tr>
        <td width="98">
          <div align="right">
            <input name="Submit" type="submit" class="botoes" value="Enviar" />
            </div></td>
        <td width="19">&nbsp;</td>
        <td width="95">
          <div align="left">
            <input name="Submit2" type="reset" class="botoes" value="Limpar" />
            </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
</form>


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="645" align="center" cellspacing="2">
  <tr>
    <td><div align="center"><span class="bodyText"><span class="style1">Powered by</span></span></div>      <div align="center"></div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="imagens/logos.gif" alt="Logos" width="213" height="33" /></div>
    <div align="center"></div></td>
  </tr>
</table>
</html>
