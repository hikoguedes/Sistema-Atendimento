<?php
session_start();
if (isset($_SESSION["login_usuario"]) AND isset($_SESSION["senha_usuario"])) {
    $login_usuario = $_SESSION["login_usuario"];
    $senha_usuario = $_SESSION["senha_usuario"];
}else{
header("Location: logar.php");
exit();/*caso nao tinha session.. quer dizer.. ele nao logou*/
} /*aqui primeiro ele checa para ver se exite essas Sessoes, e depois ele coloca o valor das sessoes nessas variaveis... para fazermos os testes!*/

if(!(empty($login_usuario) OR empty($senha_usuario)))
{
//acessa ao banco de dados
$cn = mysql_connect("localhost", "root", "1qaz2wsx");
mysql_select_db("suporte");
$resultado = mysql_query("select * from adm where username = '$login_usuario'");
if (mysql_num_rows($resultado) == 1)/*caso exista esse login.. vamos testar a senha entao*/
{
   if ($senha_usuario != mysql_result($resultado, 0, "senha"))
   {
       unset ($_SESSION["nome_usuario"]);/*apaga a session que existia mas era errada..*/
       unset ($_SESSION["sehna_usuario"]);
       header("Location: logar.php");
       exit();
   } 
}else {
       unset ($_SESSION["nome_usuario"]);
       unset ($_SESSION["sehna_usuario"]);
       header("Location: logar.php");
       exit();
}

}else{
header("Location: logar.php");
exit();/*caso das sessions estarem vazias*/
}
mysql_close($cn);
?>
<?php
include "cfonte.php";
?>