<?php
include "valida_session.php";
?>
<?php
include "status.php";
?>
<?php
include "connect.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Chamados em &quot;Andamento&quot;</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
.style3 {font-size: 12px; font-weight: bold; color: #0099FF; }
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
}
.style9 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
	letter-spacing: 0.2em;
}
.style10 {font-size: 12px; font-weight: bold; color: #0099FF; }
-->
</style>
</head>
<body bgcolor="#F4FFE4">

<?php

$begin = $_GET['begin'];
if (!$begin) { $begin = 0; }

$query = "SELECT COUNT(*) FROM registros WHERE estado = 'andamento' AND  tecnico = '$login_usuario' ORDER BY data_status DESC";
$query = mysql_query($query,$conexao);
$query = mysql_fetch_array($query);
$total = $query[0];

?>

<?php

if (($begin > 0) and ($begin <= 10)) {
   $anteriores = '<a href="ler_andamentos.php?begin=0">Anteriores</a>';
} elseif (($begin > 0) and ($begin > 10)) {
   $anteriores = '<a href="ler_andamentos.php?begin=' . ($begin-10) . '">Anteriores</a>';
} else {
   $anteriores = 'Anteriores';
}

if (($begin < $total) and (($begin+10) >= $total)) {
   $proximos = 'Pr�ximos';
} else {
   $proximos = '<a href="ler_andamentos.php?begin=' . ($begin+10) . '">Pr�ximos</a>';
}

?>
<tr>
<td height="490">&nbsp;
      <span class="bodyText">

      </span>
    <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr>
          <td height="46" class="pageName"><div align="center">
              <p>Meus Chamados em Andamento </p>
          </div></td>
        </tr>
        <tr>
          <td height="19" class="bodyText"><p align="center" class="style1">TOTAL DE MEUS CHAMADOS EM ANDAMENTO: <span class="style3"><?php echo $total; ?></span></p>            </td>
        </tr>
        <tr>
          <td height="20" align="center" class="bodyText"><span class="style1">Ordenado por data em que voc&ecirc; assumiu o atentimento.</span></td>
        </tr>
    </table>
      <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr>
          <td height="20" class="bodyText">&nbsp;
          <div align="center"></div></td>
        </tr>
      </table>
	
    <p align="center" class="pageName">
    <?php

$query = "SELECT DISTINCT * FROM registros WHERE estado = 'andamento' AND  tecnico = '$login_usuario' ORDER BY data_status DESC";
$query = mysql_query($query,$conexao);


while ($linha = mysql_fetch_array($query)) {

   $var = $linha['data_aber'];
   $var = explode(" ",$var);
   $dia = $var[0];
   $hora = $var[1];
   $dia = explode("-",$dia);
   $data = "$dia[2]/$dia[1]/$dia[0] �s $hora";
   $zar = $linha['data_status'];
   $zar = explode(" ",$zar);
   $dia2 = $zar[0];
   $hora2 = $zar[1];
   $dia2 = explode("-",$dia2);
   $data2 = "$dia2[2]/$dia2[1]/$dia2[0] �s $hora2";   
   ?></p><form id="finalizar" name="finalizar" method="post" action="update_finalizar.php">
      <table width="694" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr> 
          <td class="subHeader" id="monthformat">Setor</td>
          <td colspan="3" class="style9" id="monthformat"><?php echo $linha['setor']; ?></td>
          <td width="201" align="right" class="style9" id="monthformat"> 
            <p align="right" class="subHeader">ID</p></td>
          <td width="51" align="right" class="style9" id="monthformat"><?php echo $linha['id']; ?> 
            <div align="right"></div></td>
        </tr>
        <tr> 
          <td width="160" class="subHeader" id="monthformat">Andar</td>
          <td width="110" class="style9" id="monthformat"><?php echo $linha['andar']; ?></td>
          <td colspan="2" class="style9" id="monthformat">&nbsp;</td>
          <td align="right" class="style9" id="monthformat"><span class="subHeader">Ramal</span></td>
          <td align="right" class="style9" id="monthformat"><?php echo $linha['ramal']; ?>
            <div align="right"></div></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Contato</td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $linha['contato']; ?></td>
        </tr>
        <tr> 
          <td class="subHeader" id="monthformat">Equipamento</td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $linha['equip']; ?></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Problema Reportado</td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $linha['prob_rep']; ?></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Registrado em </td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $data; ?></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Assumido em </td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $data2; ?></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">T&eacute;cnico</td>
          <td colspan="5" class="style9" id="monthformat"><?php echo $linha['tecnico']; ?></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">STATUS</td>
          <td colspan="5" class="style9" id="monthformat"><span class="style10"><?php echo $linha['estado']; ?></span></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat">Problema Encontrado</td>
          <td colspan="5" class="style9" id="monthformat"><span class="subHeader"> 
            <textarea name="prob_enc" id="prob_enc" cols="60" wrap="physical"></textarea>
            </span></td>
        </tr>
        <tr> 
          <td valign="top" class="subHeader" id="monthformat"><p>Solu&ccedil;&atilde;o 
            </p></td>
          <td colspan="5" class="style9" id="monthformat"><span class="subHeader"> 
            <textarea name="solucao" id="solucao" cols="60" wrap="physical"></textarea>
            </span></td>
        </tr>
        <tr valign="top"> 
          <td height="27" class="subHeader" id="monthformat">&nbsp;</td>
          <td class="style9" id="monthformat">&nbsp;</td>
          <td width="135" class="style9" id="monthformat">&nbsp;</td>
          <td colspan="3" align="right" class="style9" id="monthformat"><label></label> 
            <label></label> <span class="subHeader"> 
            <input name="id" type="hidden" id="id" value="<?php echo $linha['id']; ?>" />
            </span><span class="subHeader"> 
            <input name="Submit" type="submit" class="botoes" value="FINALIZAR" />
            </span></td>
        </tr>
        <tr align="right"> 
          <td colspan="6" valign="top" class="subHeader" id="monthformat"></td>
        </tr>
        <tr> 
          <td height="27" colspan="6" align="right" valign="top" class="subHeader" id="monthformat">&nbsp;</td>
        </tr>
      </table>
      <p>&nbsp;</p>
    </form>
    <p>
      <?php
	  }
	  ?>
</p>
    <p>&nbsp;</p>
    <p>&nbsp;    </p>
    <p>&nbsp;</p>

</html>