<?php
//obtem os valores digitador
$login = $_POST["login"];
$senha = $_POST["senha"];
//acessa ao banco de dados
$cn = mysql_connect("localhost", "root", "1qaz2wsx");
mysql_select_db("suporte");

$resultado = mysql_query("select * from adm where username = '$login'");
$linhas = mysql_num_rows($resultado);
if ($linhas ==0)//testa se a consulta retornou algum registro
{
header("Location: logar.php"); 
} else {
    if ($senha != mysql_result($resultado, 0, "senha"))//confere a senha
    {
     header("Location: logar.php"); 
    }else{//usuario correto.. vamos criar os cookies com sessions...
    session_start();//nunca esque�a de por isso antes de usar session
    $_SESSION["login_usuario"] = $login;
    $_SESSION["senha_usuario"] = $senha;
    
    // redireciona par a pagina principal
    header("Location: ler_abertos.php");
    }
}
mysql_close($cn);
?>