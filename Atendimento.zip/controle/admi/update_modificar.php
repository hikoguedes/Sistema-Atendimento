<?php
include "valida_session.php";
?>
<?php
include "status.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Modificar</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4">
<p>
  <?php


if (getenv("REQUEST_METHOD") == "POST") {
   $id = $_POST['id'];
   $a = $_POST['setor'];
   $b = $_POST['ramal'];
   $c = $_POST['contato'];
   $d = $_POST['equip'];
   $e = $_POST['tecnico'];
   $f = $_POST['estado'];
   $g = $_POST['prob_rep'];
   $h = $_POST['prob_enc'];
   $i = $_POST['solucao'];
  {
      $query = "UPDATE registros SET setor='$a', ramal ='$b', contato ='$c', equip ='$d', tecnico ='$e', estado ='$f', prob_rep ='$g', prob_enc ='$h', solucao ='$i'  WHERE id='$id'";
      mysql_query($query,$conexao);
      header("Location: ler_modificar.php");
   }
}
      
?>
</html>
