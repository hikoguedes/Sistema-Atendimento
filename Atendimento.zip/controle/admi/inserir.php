<?php
include "status.php";
?>
<?php
include "connect.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title>Calendar</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4">

<?php


if (getenv("REQUEST_METHOD") == "POST") {

   $andar = $_POST['andar'];
   $setor = $_POST['setor'];
   $contato = $_POST['contato'];
   $ramal = $_POST['ramal'];
   $equipamento = $_POST['equip'];
   $prob_a = $_POST['prob_rep'];
   $tecnico = ($nome);
   if ($andar and $setor and $contato and $ramal and $equipamento and $prob_a) {
      $query = "INSERT INTO registros VALUES('0000','$andar','$setor','$contato','$ramal','$prob_a',NULL,NULL,'ABERTO',NOW(),NULL,NULL,'$tecnico','$equipamento')";
      mysql_query($query,$conexao);
      header("Location: inserir.php");
   } else {
      $err = "Preencha todos os campos!";
   }
}
      
?>
  
<?php
if ($err) {
?>
</p>
<?php
}
?>
<form method="post" action="inserir.php">



 <tr>
    <td height="490">&nbsp;
    &nbsp;<br />
    <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
        <tr>
          <td height="46" colspan="4" class="pageName"><div align="center">
            <table align="center">
              <tr>
                <td class="subHeader"><b><?php echo $err; ?></td>
              </tr>
            </table>
            <p>Controle de Atendimentos </p>
          </div></td>
        </tr>
        <tr>
          <td height="19" colspan="4" class="bodyText"><p align="center" class="style1">&nbsp;</p>		  </td>
        </tr>
        <tr>
          <td height="20" colspan="4" class="bodyText"><span class="style1">Entre aqui com os dados do chamado, o preenchimento de todos os campos &eacute; obrigat&oacute;rio.</span></td>
        </tr>
        <tr>
          <td class="subHeader" id="monthformat">Setor</td>
          <td colspan="3" class="subHeader" id="monthformat"><input name="setor" type="text" id="setor" size="60" /></td>
        </tr>
        <tr>
          <td width="94" class="subHeader" id="monthformat">Andar</td>
          <td width="58" class="subHeader" id="monthformat"><select name="andar">
            <option>05&ordm;</option>
            <option>25&ordm;</option>
            <option>26&ordm;</option>
            <option>28&ordm;</option>
            <option>29&ordm;</option>
            <option>30&ordm;</option>
          </select></td>
          <td width="50" class="subHeader" id="monthformat"><div align="left">Ramal</div></td>
          <td width="308" class="subHeader" id="monthformat"><div align="left">
            <input name="ramal" type="text" id="ramal" size="37" />
          </div></td>
        </tr>
        <tr>
          <td class="subHeader" id="monthformat">Contato</td>
          <td colspan="3" class="subHeader" id="monthformat"><input name="contato" type="text" id="contato" size="60" /></td>
        </tr>
        <tr>
          <td class="subHeader" id="monthformat">Equipamento</td>
          <td colspan="3" class="subHeader" id="monthformat"><input name="equip" type="text" id="equip" value="" size="60" /></td>
        </tr>
        <tr>
          <td valign="top" class="subHeader" id="monthformat">          Problema</td>
          <td colspan="3" class="subHeader" id="monthformat"><textarea name="prob_rep" cols="46" wrap="physical" id="prob_rep"></textarea></td>
        </tr>
        <tr>
          <td colspan="4" valign="top" class="subHeader" id="monthformat">&nbsp;</td>
        </tr>
      </table>
    <table width="332" border="0" align="center" cellspacing="2">
      <tr>
        <td width="143">
          <div align="right">
            <input name="Submit" type="submit" class="botoes" value="Enviar" />
            </div></td>
        <td width="10">&nbsp;</td>
        <td width="167">
          <div align="left">
            <input name="Submit2" type="reset" class="botoes" value="Limpar" />
            </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
</form>


<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<table width="645" align="center" cellspacing="2">
  <tr>
    <td><div align="center"><span class="bodyText"><span class="style1">Powered by</span></span></div>      <div align="center"></div></td>
  </tr>
  <tr>
    <td><div align="center"><img src="imagens/logos.gif" alt="Logos" width="213" height="33" /></div>
    <div align="center"></div></td>
  </tr>
</table>
</html>
