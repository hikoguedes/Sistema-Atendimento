<?php
include "sucesso_logout.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<!-- DW6 -->
<head>
<!-- Copyright 2005 Macromedia, Inc. All rights reserved. -->
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" href="style/mm_health_nutr.css" type="text/css" />
<script language="JavaScript" type="text/javascript">
//--------------- LOCALIZEABLE GLOBALS ---------------
var d=new Date();
var monthname=new Array("Janeiro","Fevereiro","Mar�o","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro");
//Ensure correct for language. English is "January 1, 2004"
var TODAY = monthname[d.getMonth()] + " "  + d.getDate() + ", " + d.getFullYear();
var HOJE = d.getDate() + " de "  + monthname[d.getMonth()] + " de " + d.getFullYear();
//---------------   END LOCALIZEABLE   ---------------
</script>
<style type="text/css">
<!--
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.botoes {
	background-color: #F4FFE4;
	text-align: center;
	list-style-type: square;
	font-weight: bold;
	color: #993300;
}
.style3 {font-size: 12px; font-weight: bold; color: #FF0000; }
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #000066;
	font-weight: bold;
}
-->
</style>
</head>
<body bgcolor="#F4FFE4">

<tr>
<td height="490"><p>&nbsp;
      <span class="bodyText">

      </span>
    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
      <tr> 
        <td height="46" class="pageName"><div align="center"> 
            <p>Senha Alterada com Sucesso</p>
          </div></td>
      </tr>
    </table>
      
    <table width="526" border="0" align="center" cellpadding="2" cellspacing="0">
      <tr> 
        <td height="46" class="pageName"><div align="center"> 
            <p class="style3">SUA SENHA FOI ALTERADA COM SUCESSO MAS SUA SESSAO 
              FOI FINALIZADA. <a href="logar.php">CLIQUE AQUI</a> PARA EFETUAR 
              O LOGIN COM SUA NOVA SENHA</p>
          </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p align="center" class="pageName">
</p>
    <p>&nbsp; </p>
    <p>&nbsp;</p>
    <p>&nbsp;    </p>
    <p>&nbsp;</p>

</html>