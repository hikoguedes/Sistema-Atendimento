-- Estrutura da tabela `adm`
-- 

CREATE TABLE `adm` (
  `id` bigint(2) NOT NULL auto_increment,
  `username` varchar(20) NOT NULL,
  `senha` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;