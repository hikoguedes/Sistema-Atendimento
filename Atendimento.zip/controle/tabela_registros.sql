-- 
-- Estrutura da tabela `registros`
-- 

CREATE TABLE `registros` (
  `id` bigint(4) NOT NULL auto_increment,
  `andar` varchar(200) NOT NULL,
  `setor` varchar(200) NOT NULL,
  `contato` varchar(200) NOT NULL,
  `ramal` varchar(200) NOT NULL,
  `prob_rep` text NOT NULL,
  `prob_enc` text,
  `solucao` text,
  `estado` varchar(200) default NULL,
  `data_aber` datetime default NULL,
  `data_status` datetime default NULL,
  `data_fim` datetime default NULL,
  `tecnico` varchar(200) default NULL,
  `equip` varchar(200) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=204 ;
